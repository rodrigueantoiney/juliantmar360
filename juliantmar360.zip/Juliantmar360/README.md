# Juliantmar 360 — Application Android

Application Android qui affiche le site **https://www.view.juliantmar360.com** en plein écran (WebView).

## Fonctionnalités
- Chargement du site avec barre de progression
- JavaScript, stockage local et cookies activés (connexion conservée)
- Lecture vidéo / visites 360° et mode plein écran
- Bouton « retour » du téléphone = page précédente du site
- Liens externes, téléphone (`tel:`), e-mail, WhatsApp ouverts dans les applis du téléphone
- Écran « Pas de connexion » avec bouton Réessayer
- Envoi de fichiers depuis les formulaires du site
- Android 8.0 et plus

## Option 1 — Générer l'APK avec Android Studio (ordinateur)
1. Installez [Android Studio](https://developer.android.com/studio).
2. Décompressez l'archive, puis **File > Open** et choisissez le dossier `Juliantmar360`.
3. Attendez la synchronisation Gradle.
4. **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK se trouve dans `app/build/outputs/apk/debug/app-debug.apk` : copiez-le sur le téléphone et installez-le.

## Option 2 — Générer l'APK sans ordinateur puissant (GitHub)
1. Créez un dépôt sur GitHub et envoyez-y tout le contenu du dossier.
2. L'onglet **Actions** lance automatiquement « Build APK ».
3. À la fin (≈ 5 min), téléchargez l'artefact **Juliantmar360-apk** : il contient l'APK.

## Personnaliser
| Élément | Fichier |
|---|---|
| Adresse du site | `app/src/main/java/com/juliantmar360/view/MainActivity.java` (`START_URL`) |
| Nom de l'appli | `app/src/main/res/values/strings.xml` |
| Couleurs | `app/src/main/res/values/colors.xml` |
| Icône | Android Studio : clic droit sur `res` > New > Image Asset |
| Version | `app/build.gradle` (`versionCode`, `versionName`) |

## Publier sur le Google Play Store
1. Android Studio : **Build > Generate Signed App Bundle / APK** > Android App Bundle.
2. Créez une clé de signature (gardez le fichier `.jks` et le mot de passe en lieu sûr).
3. Envoyez le fichier `.aab` dans la [Google Play Console](https://play.google.com/console) (compte développeur : 25 $ une fois).

> Note : Google peut refuser une appli qui n'est qu'une copie d'un site sans valeur ajoutée. Pour une diffusion directe (WhatsApp, site web), l'APK suffit.
